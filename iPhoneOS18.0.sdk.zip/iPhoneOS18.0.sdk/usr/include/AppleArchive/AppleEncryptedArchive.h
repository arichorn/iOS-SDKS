// AppleEncryptedArchive

#pragma once

#ifndef __APPLE_ARCHIVE_H
#error Include AppleArchive.h instead of this file
#endif

#include "AEADefs.h"
#include "AEAAuthData.h"
#include "AEAContext.h"
#include "AEAStreams.h"
